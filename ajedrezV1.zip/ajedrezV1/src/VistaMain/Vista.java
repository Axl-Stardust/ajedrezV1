package VistaMain;

import Modelo.*;
import Controlador.*;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.*;
import java.nio.file.*;

public class Vista extends JFrame implements ActionListener {
    private final GridBagLayout layout ;
    private final GridBagConstraints constraints ;
    JButton btnPgn, btnReset, btnEnd, btnPreMove, btnNxtMove, btnSave, btnPlay;
    JLabel searchGameLabel, searchMoveLabel, pgnLabel, gameLabel, moveLabel, colorLabel;
    JRadioButton whiteRadio, blackRadio;
    ButtonGroup bg;
    Timer timer;
    private PGN pgn;
    private Juego game;
    private boolean isSelected, isMove, notFlip, isPlay;
    private int indexOfGame, indexOfMove;


    public Vista(){
        super("Ajedrez PGN");

        layout = new GridBagLayout();

        setLayout(layout);
        constraints = new GridBagConstraints();

        notFlip = true;
        indexOfMove = -1;
        timer = new Timer(750, this);
        timer.start();
        setResizable(false);

        //create tagsArea
        pgnLabel = new JLabel("");
        moveLabel = new JLabel("");
        colorLabel = new JLabel("");
        gameLabel = new JLabel("");


        //add component to info panel
        //figurine checkbox and move stat checkbox would add later
        constraints.insets = new Insets(0, 0, 10, 0);
        addComponentToInfoPanel(pgnLabel, 0);
        addComponentToInfoPanel(gameLabel, 3);
        constraints.insets = new Insets(0, 0, 9, 0);
        addComponentToInfoPanel(moveLabel, 2);
        constraints.insets = new Insets(0, 0, 6, 0);
        addComponentToInfoPanel(colorLabel, 3);

        //create buttons
        btnPgn = new JButton ("Abrir archivo PGN");
        btnPgn.addActionListener(e -> {
            JFileChooser j = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
            j.setAcceptAllFileFilterUsed(false);
            j.setDialogTitle("Selecciona un archivo");
            FileNameExtensionFilter restrict = new FileNameExtensionFilter("Archivos PGN (.pgn)", "pgn");
            j.addChoosableFileFilter(restrict);
            int r = j.showOpenDialog(null);
            if (r == JFileChooser.APPROVE_OPTION) {
                pgn = new PGN(j.getSelectedFile().getAbsolutePath());

                //add figurine checkbox and to5 checkbox to info panel
                addFigurineCheckBox();
                addTop5CheckBox();

                //set variables
                isSelected = true;
                indexOfGame = 0;

                //set labels in info panel
                String nameOfFile = j.getSelectedFile().getName();
                pgnLabel.setText(nameOfFile.substring(0, nameOfFile.length()-4));

                setGameButton();
            }
        });




        btnReset = new JButton ("Resetear");
        btnReset.addActionListener(e -> {
            if(isSelected){
                //set variables
                isMove = false;
                isPlay = false;
                indexOfMove = -1;

                //reset board
                game.board.resetBoard();

                //set labels of info panel
                int size = game.board.getMoves().size();
                size = (size/2)+(size%2);
                moveLabel.setText("Movimiento "+(indexOfMove + 1)+" de "+size);
                colorLabel.setText("");

                btnPlay.setText("Iniciar");
                repaint();
            }
        });

        btnEnd = new JButton ("Final");
        btnEnd.addActionListener(e -> {
            if(isSelected && indexOfMove < game.board.getMoves().size()-1){
                //set variables
                isMove = true;
                isPlay = false;
                indexOfMove = game.board.getMoves().size()-1;

                //perform every move to reach the end of game
                for(int i = 0; i <= indexOfMove; i++)
                    game.board.doMove(game.board.getMoves().get(i));

                //set labels of info panel
                int size = game.board.getMoves().size();
                size = (size/2)+(size%2);
                if(indexOfMove+1 != 0 && (indexOfMove+1) % 2 == 1) {
                    moveLabel.setText("Movimiento " + ((indexOfMove + 2) / 2) + " de " + size);
                    colorLabel.setText("Piezas blancas");
                }
                else if(indexOfMove+1 != 0) {
                    moveLabel.setText("Movimiento " + ((indexOfMove + 1) / 2) + " de " + size);
                    colorLabel.setText("Piezas negras");
                }

                btnPlay.setText("Iniciar");
                repaint();
            }
        });


        btnPreMove = new JButton ("Movimiento anterior");
        btnPreMove.addActionListener(e -> {
            if(isSelected && indexOfMove >= 0){
                //set variables
                isMove = true;
                isPlay = false;
                indexOfMove--;

                //undo last move
                game.board.undoMove();

                //set labels of info panel
                int size = game.board.getMoves().size();
                size = (size/2)+(size%2);
                if(indexOfMove+1 != 0 && (indexOfMove+1) % 2 == 1) {
                    moveLabel.setText("Movimiento " + ((indexOfMove + 2) / 2) + " de " + size);
                    colorLabel.setText("Piezas blancas");
                }
                else if(indexOfMove+1 != 0) {
                    moveLabel.setText("Movimiento " + ((indexOfMove + 1) / 2) + " de " + size);
                    colorLabel.setText("Piezas negras");
                }
                else {
                    moveLabel.setText("Primer movimiento de " + size);
                    colorLabel.setText("");
                }

                btnPlay.setText("Iniciar");
                repaint();
            }
        });

        btnNxtMove = new JButton ("Siguiente movimiento");
        btnNxtMove.addActionListener(e -> {
            if(isSelected && indexOfMove < game.board.getMoves().size()-1){
                //set variables
                isMove = true;
                isPlay = false;
                indexOfMove++;

                //perform next move
                game.board.doMove(game.board.getMoves().get(indexOfMove));

                //set labels of info panel
                int size = game.board.getMoves().size();
                size = (size/2)+(size%2);
                if(indexOfMove+1 != 0 && (indexOfMove+1) % 2 == 1) {
                    moveLabel.setText("Movimiento " + ((indexOfMove + 2) / 2) + " de " + size);
                    colorLabel.setText("Piezas blancas");
                }
                else if(indexOfMove+1 != 0) {
                    moveLabel.setText("Movimiento " + ((indexOfMove + 1) / 2) + " de " + size);
                    colorLabel.setText("Piezas negras");
                }

                btnPlay.setText("Iniciar");
                repaint();
            }
        });

        btnSave = new JButton ("Guardar partida");
        btnSave.addActionListener(e -> {
            if(isSelected && indexOfMove < game.board.getMoves().size()-1) {
                ChessSaveHandler saveHandler = new ChessSaveHandler(this);
                saveHandler.configureSaveButton(btnSave, game);
            }
        });

        btnPlay = new JButton ("Iniciar");
        btnPlay.addActionListener(e -> {
            if(isSelected && indexOfMove < game.board.getMoves().size()-1) {
                isPlay = !isPlay;
                if (isPlay)
                    btnPlay.setText("Pausa");
                else
                    btnPlay.setText("Iniciar");
            }
        });

        //add chessboard
        constraints.insets = new Insets(0, 0, 0, 0);
        addComponent(new ChessBoard(), 10, 0, 8,8);

        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.weightx = 1;

        //add pgn button
        constraints.insets = new Insets(10, 5, 0, 5);
        addComponent(btnPgn, 2 , 1 , 9 , 1);

        //add move buttons
        constraints.insets = new Insets(5, 5, 0, 5);
        addComponent(btnPreMove, 3 , 1 , 3 , 1);

        constraints.insets = new Insets(5, 6, 0, 5);
        addComponent(btnNxtMove, 3 , 3, 5 , 1);

        constraints.insets = new Insets(5, 5, 0, 5);
        addComponent(btnReset, 4 , 1 , 3 , 1);

        constraints.insets = new Insets(5, 6, 0, 5);
        addComponent(btnEnd, 4 , 3 , 5 , 1);

        constraints.insets = new Insets(5, 5, 0, 0);
        addComponent(btnSave, 6 , 3 , 2 , 1);

        //add play button
        constraints.insets = new Insets(5, 3, 0, 0);
        addComponent(btnPlay, 6 , 1 , 2 , 1);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        pack();
        setVisible(true);
        setLocationRelativeTo(null);
    }

    /**
     * creacion del panel para el tablero
     */
    private class ChessBoard extends JPanel{
        final int UNIT_SIZE = 60;
        final int SCREEN_SIZE = 8*UNIT_SIZE;

        ChessBoard() {
            setPreferredSize(new Dimension(SCREEN_SIZE, SCREEN_SIZE));
            setBackground(new Color(255, 241, 200));
            setFocusable(true);
        }

        @Override
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            draw(g);
        }

        public void draw(Graphics g) {
            // paint the board
            g.setColor(new Color(0, 13, 96));
            for(int i = 0; i <= SCREEN_SIZE; i += UNIT_SIZE) {
                for(int j = 0; j <= SCREEN_SIZE; j += UNIT_SIZE) {
                    if (((i / UNIT_SIZE) % 2 == 0 && (j / UNIT_SIZE) % 2 != 0)
                            || ((i / UNIT_SIZE) % 2 != 0 && (j / UNIT_SIZE) % 2 == 0))
                        g.fillRect(i, j, UNIT_SIZE, UNIT_SIZE);
                }
            }

            //paint the move (show initial and final square of move)
            if(isMove){
                Movimientos movimientos;
                if(indexOfMove >= 0)
                    movimientos = game.board.getMoves().get(indexOfMove);
                else
                    movimientos = game.board.getMoves().get(0);
                g.setColor(new Color(0, 231, 204));
                if(movimientos.getTypeOfConstructor() != 3) {
                    int[] s1 = Metodo.getPosition(movimientos.getFrom());
                    int[] s2 = Metodo.getPosition(movimientos.getTo());
                    if(notFlip) {
                        g.fillRect(s1[1] * UNIT_SIZE, (7 - s1[0]) * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
                        g.fillRect(s2[1] * UNIT_SIZE, (7 - s2[0]) * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
                    } else {
                        g.fillRect((7-s1[1]) * UNIT_SIZE, (s1[0]) * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
                        g.fillRect((7-s2[1]) * UNIT_SIZE, (s2[0]) * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
                    }
                } else {
                    if(movimientos.isWhite()){
                        if(movimientos.isKingSideCastle()){
                            if(notFlip) {
                                g.fillRect((6) * UNIT_SIZE, (7) * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
                                g.fillRect((4) * UNIT_SIZE, (7) * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
                            } else {
                                g.fillRect( UNIT_SIZE, 0, UNIT_SIZE, UNIT_SIZE);
                                g.fillRect((3) * UNIT_SIZE, 0, UNIT_SIZE, UNIT_SIZE);
                            }
                        }
                        else if(movimientos.isQueenSideCastle()){
                            if(notFlip) {
                                g.fillRect((4) * UNIT_SIZE, (7) * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
                                g.fillRect((2) * UNIT_SIZE, (7) * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
                            } else {
                                g.fillRect((3) * UNIT_SIZE, 0, UNIT_SIZE, UNIT_SIZE);
                                g.fillRect((5) * UNIT_SIZE, 0, UNIT_SIZE, UNIT_SIZE);
                            }
                        }
                    } else{
                        if(movimientos.isKingSideCastle()){
                            if(notFlip) {
                                g.fillRect((6) * UNIT_SIZE, 0, UNIT_SIZE, UNIT_SIZE);
                                g.fillRect((4) * UNIT_SIZE, 0, UNIT_SIZE, UNIT_SIZE);
                            } else {
                                g.fillRect( UNIT_SIZE, (7) * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
                                g.fillRect((3) * UNIT_SIZE, (7) * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
                            }
                        }
                        else if(movimientos.isQueenSideCastle()){
                            if(notFlip) {
                                g.fillRect((4) * UNIT_SIZE, 0, UNIT_SIZE, UNIT_SIZE);
                                g.fillRect((2) * UNIT_SIZE, 0, UNIT_SIZE, UNIT_SIZE);
                            } else {
                                g.fillRect((3) * UNIT_SIZE, (7) * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
                                g.fillRect((5) * UNIT_SIZE, (7) * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
                            }
                        }
                    }
                }
            }

            // draw coordinates of squares
            g.setFont(new Font("Arial", Font.BOLD, 15));
            for(int i = 8; i > 0; i--){
                if(i % 2 == 1)
                    g.setColor(new Color(255, 241, 200));
                else
                    g.setColor(new Color(0, 13, 96));
                g.drawString(String.valueOf(i),2,13+UNIT_SIZE*(8-i));
                g.drawString(String.valueOf((char)(i+96)),(i)*UNIT_SIZE-10,8*UNIT_SIZE-5);
            }

            //draw image of pieces
            BufferedImage image = null;
            try {
                for(int i = 0; i < 8; i++) {
                    for (int j = 0; j < 8; j++) {
                        Ficha piece = Metodo.getPiece(new int[]{i, j});
                        if(piece != Ficha.NONE) {
                            switch (piece) {
                                case WHITE_PAWN -> image = ImageIO.read(new File("src/Recursos/wp.png"));
                                case BLACK_PAWN -> image = ImageIO.read(new File("src/Recursos/bp.png"));
                                case WHITE_ROOK -> image = ImageIO.read(new File("src/Recursos/wr.png"));
                                case BLACK_ROOK -> image = ImageIO.read(new File("src/Recursos/br.png"));
                                case WHITE_KNIGHT -> image = ImageIO.read(new File("src/Recursos/wn.png"));
                                case BLACK_KNIGHT -> image = ImageIO.read(new File("src/Recursos/bn.png"));
                                case WHITE_BISHOP -> image = ImageIO.read(new File("src/Recursos/wb.png"));
                                case BLACK_BISHOP -> image = ImageIO.read(new File("src/Recursos/bb.png"));
                                case WHITE_QUEEN -> image = ImageIO.read(new File("src/Recursos/wq.png"));
                                case BLACK_QUEEN -> image = ImageIO.read(new File("src/Recursos/bq.png"));
                                case WHITE_KING -> image = ImageIO.read(new File("src/Recursos/wk.png"));
                                case BLACK_KING -> image = ImageIO.read(new File("src/Recursos/bk.png"));
                            }
                            if(notFlip)
                                g.drawImage(image, j * UNIT_SIZE, (7-i) * UNIT_SIZE, null);
                            else
                                g.drawImage(image, (7-j) * UNIT_SIZE, i * UNIT_SIZE, null);
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    class ChessSaveHandler {

        private final JFrame parentFrame;

        public ChessSaveHandler(JFrame parentFrame) {
            this.parentFrame = parentFrame;
        }

        public void configureSaveButton(JButton btnSave, Juego game) {
            btnSave.addActionListener(e -> saveGameWithDialog(game));
        }

        private void saveGameWithDialog(Juego game) {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setFileFilter(new FileNameExtensionFilter(
                    "Archivos PGN (*.pgn)", "pgn"));

            String pgn = game.getStrMovesText();

            if (pgn == null || pgn.trim().isEmpty()) {
                JOptionPane.showMessageDialog(parentFrame,
                        "No hay movimientos para guardar.",
                        "Advertencia",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            int result = fileChooser.showSaveDialog(parentFrame);

            if (result == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();

                if (!selectedFile.getName().toLowerCase().endsWith(".pgn")) {
                    selectedFile = new File(selectedFile.getAbsolutePath() + ".pgn");
                }

                if (selectedFile.exists()) {
                    int response = JOptionPane.showConfirmDialog(parentFrame,
                            "El archivo ya existe. ¿Desea sobrescribirlo?",
                            "Confirmar sobrescritura",
                            JOptionPane.YES_NO_OPTION,
                            JOptionPane.WARNING_MESSAGE);

                    if (response != JOptionPane.YES_OPTION) {
                        return;
                    }
                }

                guardarPartidaPGN(pgn, selectedFile);
            }
        }

        private void guardarPartidaPGN(String pgn, File archivo) {
            try {
                Files.createDirectories(archivo.getParentFile().toPath());
                Files.write(archivo.toPath(), pgn.getBytes());

                JOptionPane.showMessageDialog(parentFrame,
                        "Partida guardada exitosamente en:\n" + archivo.getPath(),
                        "Éxito",
                        JOptionPane.INFORMATION_MESSAGE);

            } catch (IOException e) {
                String mensaje = "Error al guardar la partida:\n" + e.getMessage();
                JOptionPane.showMessageDialog(parentFrame,
                        mensaje,
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                System.err.println(mensaje);
            }
        }
    }

    /**
     * add component to frame
     */
    private void addComponent(Component component, int row, int column, int width, int height) {
        constraints.gridx = column;
        constraints.gridy = row;
        constraints.gridwidth = width;
        constraints.gridheight = height;
        layout.setConstraints(component, constraints);
        add(component);
    }

    /**
     * add component to info panel
     */
    private void addComponentToInfoPanel(Component component, int row){
        constraints.gridx = 0;
        constraints.gridy = row;
        layout.setConstraints(component, constraints);
    }

    /**
     * set text areas
     */
    private JScrollPane setTextArea(JTextArea textArea){
        textArea.setFont(new Font("Sans-Serif", Font.BOLD, 15));
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setEditable(false);
        return new JScrollPane(textArea, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
    }

    /**
     * add figurine checkbox to info panel
     */
    private void addFigurineCheckBox(){
        if(!isSelected) {
            constraints.fill = GridBagConstraints.NONE;
            constraints.weightx = 0;
            constraints.insets = new Insets(0, 0, 0, 0);
            constraints.gridwidth = 1;
            constraints.gridheight = 1;
        }
    }

    /**
     * add top 5 checkbox to info panel
     */
    private void addTop5CheckBox(){
        if(!isSelected) {
            constraints.fill = GridBagConstraints.NONE;
            constraints.weightx = 0;
            constraints.insets = new Insets(0, 0, 0, 0);
            constraints.gridwidth = 1;
            constraints.gridheight = 1;
        }
    }

    /**
     * add common lines to pgn and game buttons
     */
    private void setGameButton(){
        //set variables
        isMove = false;
        isPlay = false;
        indexOfMove = -1;

        //set the game
        game = pgn.getGames().get(indexOfGame);
        game.board = new Tablero(Conversor.convertMoves(game.getStringMovesArray()));
        game.board.resetBoard();

        //set labels in info panel
        int size = game.board.getMoves().size();
        size = (size/2)+(size%2);
        moveLabel.setText("Movimiento "+(indexOfMove + 1)+" de "+size);
        colorLabel.setText("");

        //set play button's text
        btnPlay.setText("Iniciar");

        repaint();
    }

    /**
     * perform moves in order
     */
    private void play(){
        if(isSelected && indexOfMove < game.board.getMoves().size()-1){
            indexOfMove++;
            isMove = true;
            game.board.doMove(game.board.getMoves().get(indexOfMove));
            int size = game.board.getMoves().size();
            size = (size/2)+(size%2);
            if(indexOfMove+1 != 0 && (indexOfMove+1) % 2 == 1) {
                moveLabel.setText("Movimiento " + ((indexOfMove + 2) / 2) + " de " + size);
                colorLabel.setText("Piezas blancas");
            }
            else if(indexOfMove+1 != 0) {
                moveLabel.setText("Movimiento " + ((indexOfMove + 1) / 2) + " de " + size);
                colorLabel.setText("Piezas negras");
            }
        }
    }

    /**
     * convert move string to figurine
     */
    private String toFigurine(String s){
        if(indexOfMove % 2 == 0){
            for(int i = 0; i < s.length(); i++) {
                switch (s.charAt(i)) {
                    case 'R' -> s = s.replaceFirst("R", "♖");
                    case 'N' -> s = s.replaceFirst("N", "♘");
                    case 'B' -> s = s.replaceFirst("B", "♗");
                    case 'Q' -> s = s.replaceFirst("Q", "♕");
                    case 'K' -> s = s.replaceFirst("K", "♔");
                }
            }
        } else {
            for(int i = 0; i < s.length(); i++) {
                switch (s.charAt(i)) {
                    case 'R' -> s = s.replaceFirst("R", "♜");
                    case 'N' -> s = s.replaceFirst("N", "♞");
                    case 'B' -> s = s.replaceFirst("B", "♝");
                    case 'Q' -> s = s.replaceFirst("Q", "♛");
                    case 'K' -> s = s.replaceFirst("K", "♚");
                }
            }
        }
        return s;
    }

    /**
     * convert move text to figurine text
     */
    private String figurineText(String s){
        for(int i = 0; i < s.length(); i++) {
            if(i > 1)
                i--;
            if (s.charAt(i) == '.') {
                i++;
                while(s.charAt(i) != '.') {
                    if(s.charAt(i) == ' ')
                        i++;
                    while(s.charAt(i) != ' ') {
                        switch (s.charAt(i)) {
                            case 'R' -> s = s.replaceFirst("R", "♖");
                            case 'N' -> s = s.replaceFirst("N", "♘");
                            case 'B' -> s = s.replaceFirst("B", "♗");
                            case 'Q' -> s = s.replaceFirst("Q", "♕");
                            case 'K' -> s = s.replaceFirst("K", "♔");
                        }
                        i++;
                    }
                    while(s.charAt(i) != '.') {
                        switch (s.charAt(i)) {
                            case 'R' -> s = s.replaceFirst("R", "♜");
                            case 'N' -> s = s.replaceFirst("N", "♞");
                            case 'B' -> s = s.replaceFirst("B", "♝");
                            case 'Q' -> s = s.replaceFirst("Q", "♛");
                            case 'K' -> s = s.replaceFirst("K", "♚");
                        }
                        i++;
                        if(i >= s.length())
                            break;
                    }
                    if(i >= s.length())
                        break;
                }
            }
        }
        return s;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(isPlay) {
            play();
            if(indexOfMove == game.board.getMoves().size()-1){
                isPlay = false;
                btnPlay.setText("Iniciar");
            }
            repaint();
        }
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(Vista::new);
    }
}