package Modelo;

import Controlador.Metodo;

import java.util.ArrayList;
import java.util.Stack;

public class Tablero extends Metodo {
    private ArrayList<Movimientos> movimientos;
    private final Stack<Movimientos> movesPerformed;
    static char[][] finalPositions;
    private final ArrayList<Ficha> capturedPieces;

    Tablero(){
        movimientos = new ArrayList<>();
        movesPerformed = new Stack<>();
        finalPositions = buildFinalPosition();
        capturedPieces = new ArrayList<>();
    }

    public Tablero(ArrayList<Movimientos> movimientos){
        this.setMoves(movimientos);
        movesPerformed = new Stack<>();
        finalPositions = buildFinalPosition();
        capturedPieces = new ArrayList<>();
    }

    public ArrayList<Movimientos> getMoves() {
        return movimientos;
    }

    public void setMoves(ArrayList<Movimientos> movimientos) {
        this.movimientos = movimientos;
    }

    /**
     * it perform a move from moves.
     */
    public void doMove(Movimientos movimientos){
        if(movimientos.getTypeOfConstructor() == 1)
            movesPerformed.push(new Movimientos(movimientos.getFrom(), movimientos.getTo(), movimientos.getMovingPiece(), movimientos.getStringMove()));
        else if(movimientos.getTypeOfConstructor() == 2){
            movesPerformed.push(new Movimientos(movimientos.getFrom(), movimientos.getTo(), movimientos.getMovingPiece(), movimientos.getCaptured(), movimientos.getSpecialPawn(), false, movimientos.getStringMove()));
            if(movimientos.getCaptured() == Ficha.NONE){
                if(movimientos.getMovingPiece() == Ficha.WHITE_PAWN)
                    capturedPieces.add(Ficha.BLACK_PAWN);
                else
                    capturedPieces.add(Ficha.WHITE_PAWN);
            } else {
                if((Metodo.getPosition(movimientos.getTo())[0] != 0 && Metodo.getPosition(movimientos.getTo())[0] != 7)
                        || (movimientos.getCaptured() != Ficha.WHITE_PAWN && movimientos.getCaptured() != Ficha.BLACK_PAWN))
                    capturedPieces.add(movimientos.getCaptured());
            }
        }
        else
            movesPerformed.push(new Movimientos(movimientos.isWhite(), movimientos.isKingSideCastle(), movimientos.isQueenSideCastle(), false, movimientos.getStringMove()));
    }

    /**
     * it undo the last move.
     */
    public void undoMove() {
        if (!movesPerformed.empty()) {
            Movimientos lastMovimientos = movesPerformed.pop();
            if (lastMovimientos.getTypeOfConstructor() == 1)
                new Movimientos(lastMovimientos.getTo(), lastMovimientos.getFrom(), lastMovimientos.getMovingPiece(), lastMovimientos.getStringMove());
            else if (lastMovimientos.getTypeOfConstructor() == 2) {
                new Movimientos(lastMovimientos.getFrom(), lastMovimientos.getTo(), lastMovimientos.getMovingPiece(), lastMovimientos.getCaptured(), lastMovimientos.getSpecialPawn(), true, lastMovimientos.getStringMove());
                if (lastMovimientos.getCaptured() == Ficha.NONE) {
                    if (lastMovimientos.getMovingPiece() == Ficha.WHITE_PAWN)
                        capturedPieces.remove(Ficha.BLACK_PAWN);
                    else
                        capturedPieces.remove(Ficha.WHITE_PAWN);
                } else {
                    if((Metodo.getPosition(lastMovimientos.getTo())[0] != 0 && Metodo.getPosition(lastMovimientos.getTo())[0] != 7)
                            || (lastMovimientos.getCaptured() != Ficha.WHITE_PAWN && lastMovimientos.getCaptured() != Ficha.BLACK_PAWN))
                        capturedPieces.remove(lastMovimientos.getCaptured());
                }
            } else
                new Movimientos(lastMovimientos.isWhite(), lastMovimientos.isKingSideCastle(), lastMovimientos.isQueenSideCastle(), true, lastMovimientos.getStringMove());
        }
    }

    /**
     * it returns all captured pieces to the point of game that method is called.
     */
    public ArrayList<Ficha> capturedPieces(){
        return capturedPieces;
    }

    /**
     * it reset position of pieces to initial position of chess game.
     * it also removes all performed moves and captured pieces.
     */
    public void resetBoard(){
        finalPositions = buildFinalPosition();
        movesPerformed.removeAllElements();
        capturedPieces.clear();
    }

    /**
     * it would build an char[][] base on initial position of chess game.
     */
    private char[][] buildFinalPosition(){
        Metodo.resetSquares();
        char[][] finalPosition = new char[8][8];
        for(int i = 0; i < 8; i++){
            for(int j = 0; j < 8; j++){
                finalPosition[i][j] = Metodo.getNotationPiece(new int[]{i, j});
            }
        }
        return finalPosition;
    }

    @Override
    public String toString(){
        StringBuilder result = new StringBuilder();
        for (int i = 7; i >= 0; i--) {
            for (int j = 0; j < 8; j++)
                result.append(finalPositions[i][j]);
            if(i != 0)
                result.append("\n");
            else
                result.append("\nSide: WHITE");
        }
        return result.toString();
    }
}

