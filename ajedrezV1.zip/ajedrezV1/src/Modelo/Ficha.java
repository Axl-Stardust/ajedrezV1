package Modelo;

import java.util.HashMap;

public enum Ficha {
    //white pieces
    WHITE_ROOK, WHITE_KNIGHT, WHITE_BISHOP,
    WHITE_QUEEN, WHITE_KING, WHITE_PAWN,

    //black pieces
    BLACK_ROOK, BLACK_KNIGHT, BLACK_BISHOP,
    BLACK_QUEEN, BLACK_KING, BLACK_PAWN,

    //none
    NONE;

    public static HashMap<Ficha, Character> notation = new HashMap<>();
    static {
        //white pieces
        notation.put(Ficha.WHITE_ROOK, 'R');
        notation.put(Ficha.WHITE_KNIGHT, 'N');
        notation.put(Ficha.WHITE_BISHOP, 'B');
        notation.put(Ficha.WHITE_QUEEN, 'Q');
        notation.put(Ficha.WHITE_KING, 'K');
        notation.put(Ficha.WHITE_PAWN, 'P');

        //black pieces
        notation.put(Ficha.BLACK_ROOK, 'r');
        notation.put(Ficha.BLACK_KNIGHT, 'n');
        notation.put(Ficha.BLACK_BISHOP, 'b');
        notation.put(Ficha.BLACK_QUEEN, 'q');
        notation.put(Ficha.BLACK_KING, 'k');
        notation.put(Ficha.BLACK_PAWN, 'p');

        //none
        notation.put(Ficha.NONE, ' ');
    }
}

