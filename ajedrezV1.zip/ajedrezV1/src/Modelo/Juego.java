package Modelo;

import java.util.LinkedHashMap;

public class Juego {
    public Tablero board;
    private final LinkedHashMap<String, String> tags;
    private String[] stringMovesArray;
    private String strMovesText;

    Juego(String event, String site, String date, String round, String whitePlayer, String blackPlayer,
          String result, String whiteTitle, String blackTitle, String whiteElo, String blackElo, String eco,
          String opening, String variation, String whiteFideId, String blackFideId, String eventDate,
          String termination, Tablero board, String strMovesText, String[] stringMovesArray){
        tags = new LinkedHashMap<>();
        this.setEvent(event);
        this.setSite(site);
        this.setDate(date);
        this.setRound(round);
        this.setWhitePlayer(whitePlayer);
        this.setBlackPlayer(blackPlayer);
        this.setResult(result);
        this.setWhiteElo(whiteElo);
        this.setBlackElo(blackElo);
        this.setOpening(opening);
        this.setStringMovesArray(stringMovesArray);
        this.board = board;
        //this.board = new Board(Controller.Converter.convertMoves(getStringMovesArray()));
        this.setStrMovesText(strMovesText);
    }

    public void setEvent(String event) {
        tags.put("Partida", event);
    }

    public void setSite(String site) {
        tags.put("Lugar", site);
    }

    public void setDate(String date) {
        tags.put("Fecha", date);
    }

    public void setRound(String round) {
        tags.put("Ronda", round);
    }

    public void setWhiteElo(String whiteElo) {
        tags.put("Ventaja (B)", whiteElo);
    }

    public void setBlackElo(String blackElo) {
        tags.put("Ventaja (N)", blackElo);
    }

    public String getWhitePlayer() {
        return tags.get("Blancas");
    }

    public void setWhitePlayer(String whitePlayer) {
        tags.put("Piezas blancas", whitePlayer);
    }

    public String getBlackPlayer() {
        return tags.get("Negras");
    }

    public void setBlackPlayer(String blackPlayer) {
        tags.put("Piezas negras", blackPlayer);
    }

    public String getOpening() {
        return tags.get("Apertura");
    }

    public void setOpening(String opening) {
        tags.put("Apertura", opening);
    }

    public String getResult() {
        return tags.get("Resultado");
    }

    public void setResult(String result) {
        tags.put("Resultado", result);
    }

    public String getStrMovesText() {
        return strMovesText;
    }

    public void setStrMovesText(String strMovesText) {
        this.strMovesText = strMovesText;
    }

    public String[] getStringMovesArray() {
        return stringMovesArray;
    }

    public void setStringMovesArray(String[] stringMovesArray) {
        this.stringMovesArray = stringMovesArray;
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();
        for(String tag: tags.keySet()){
            if(tags.get(tag) != null)
                result.append(tag).append(":   ").append(tags.get(tag)).append("\n");
        }
        if(result.toString().contains("\n")) {
            int lastNextLine = result.lastIndexOf("\n");
            return result.delete(lastNextLine, lastNextLine + 2).toString();
        } else {
            return result.toString();
        }
    }
}

