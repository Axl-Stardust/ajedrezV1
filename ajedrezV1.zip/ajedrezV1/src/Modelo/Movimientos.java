package Modelo;

import Controlador.*;

public class Movimientos extends Metodo {
    private Recuadros from;
    private Recuadros to;
    private Ficha movingPiece;
    private Ficha captured;
    private Ficha specialPawn;
    private boolean white;
    private boolean kingSideCastle;
    private boolean queenSideCastle;
    private boolean reverse;
    private int typeOfConstructor;
    private String stringMove;

    public Movimientos(Recuadros s1, Recuadros s2, Ficha movingPiece, String stringMove){
        this.setFrom(s1);
        this.setTo(s2);
        this.setMovingPiece(movingPiece);
        this.setTypeOfConstructor(1);
        if(stringMove != null)
            this.setStringMove(stringMove);

        setNewPosition(s1, Ficha.NONE);
        setNewPosition(s2, movingPiece);
    }

    public Movimientos(Recuadros s1, Recuadros s2, Ficha movingPiece, Ficha captured, Ficha specialPawn, boolean reverse, String stringMove){
        this.setFrom(s1);
        this.setTo(s2);
        this.setMovingPiece(movingPiece);
        this.setCaptured(captured);
        this.setSpecialPawn(specialPawn);
        this.setReverse(reverse);
        this.setTypeOfConstructor(2);
        this.setStringMove(stringMove);

        if(notReverse())
            new Movimientos(s1, s2, movingPiece, null);
        else {
            if ((Metodo.getPosition(s1)[0] != 0 && Metodo.getPosition(s2)[0] != 7)
                    || (captured != Ficha.WHITE_PAWN && captured != Ficha.BLACK_PAWN)) {
                setNewPosition(s2, captured);
                if (specialPawn == Ficha.NONE)
                    setNewPosition(s1, movingPiece);
                else
                    setNewPosition(s1, specialPawn);
            } else {
                setNewPosition(s1, captured);
                setNewPosition(s2, Ficha.NONE);
            }
        }

        if (captured == Ficha.NONE) {
            if (movingPiece == Ficha.WHITE_PAWN) {
                int[] enPassant = new int[]{Metodo.getPosition(s2)[0] - 1, Metodo.getPosition(s2)[1]};
                if(notReverse())
                    setNewPosition(enPassant, Ficha.NONE);
                else
                    setNewPosition(enPassant, Ficha.BLACK_PAWN);
            }
            else if (movingPiece == Ficha.BLACK_PAWN) {
                int[] enPassant = new int[]{Metodo.getPosition(s2)[0] + 1, Metodo.getPosition(s2)[1]};
                if(notReverse())
                    setNewPosition(enPassant, Ficha.NONE);
                else
                    setNewPosition(enPassant, Ficha.WHITE_PAWN);
            }
        }
    }

    public Movimientos(boolean white, boolean kingSideCastle, boolean queenSideCastle, boolean reverse, String stringMove){
        this.setWhite(white);
        this.setKingSideCastle(kingSideCastle);
        this.setQueenSideCastle(queenSideCastle);
        this.setReverse(reverse);
        this.setTypeOfConstructor(3);
        this.setStringMove(stringMove);
        if (white) {
            if (kingSideCastle) {
                if(notReverse()) {
                    new Movimientos(Recuadros.E1, Recuadros.G1, Ficha.WHITE_KING, null);
                    new Movimientos(Recuadros.H1, Recuadros.F1, Ficha.WHITE_ROOK, null);
                } else {
                    new Movimientos(Recuadros.G1, Recuadros.E1, Ficha.WHITE_KING, null);
                    new Movimientos(Recuadros.F1, Recuadros.H1, Ficha.WHITE_ROOK, null);
                }
            }
            if (queenSideCastle) {
                if(notReverse()) {
                    new Movimientos(Recuadros.E1, Recuadros.C1, Ficha.WHITE_KING, null);
                    new Movimientos(Recuadros.A1, Recuadros.D1, Ficha.WHITE_ROOK, null);
                } else {
                    new Movimientos(Recuadros.C1, Recuadros.E1, Ficha.WHITE_KING, null);
                    new Movimientos(Recuadros.D1, Recuadros.A1, Ficha.WHITE_ROOK, null);
                }
            }
        } else {
            if (kingSideCastle) {
                if(notReverse()) {
                    new Movimientos(Recuadros.E8, Recuadros.G8, Ficha.BLACK_KING, null);
                    new Movimientos(Recuadros.H8, Recuadros.F8, Ficha.BLACK_ROOK, null);
                } else {
                    new Movimientos(Recuadros.G8, Recuadros.E8, Ficha.BLACK_KING, null);
                    new Movimientos(Recuadros.F8, Recuadros.H8, Ficha.BLACK_ROOK, null);
                }
            }
            if (queenSideCastle) {
                if(notReverse()) {
                    new Movimientos(Recuadros.E8, Recuadros.C8, Ficha.BLACK_KING, null);
                    new Movimientos(Recuadros.A8, Recuadros.D8, Ficha.BLACK_ROOK, null);
                } else {
                    new Movimientos(Recuadros.C8, Recuadros.E8, Ficha.BLACK_KING, null);
                    new Movimientos(Recuadros.D8, Recuadros.A8, Ficha.BLACK_ROOK, null);
                }
            }
        }

    }

    public Recuadros getFrom() {
        return from;
    }

    public void setFrom(Recuadros from) {
        this.from = from;
    }

    public Recuadros getTo() {
        return to;
    }

    public void setTo(Recuadros to) {
        this.to = to;
    }

    public Ficha getMovingPiece() {
        return movingPiece;
    }

    public void setMovingPiece(Ficha movingPiece) {
        this.movingPiece = movingPiece;
    }

    public Ficha getCaptured() {
        return captured;
    }

    public void setCaptured(Ficha captured) {
        this.captured = captured;
    }

    public Ficha getSpecialPawn() {
        return specialPawn;
    }

    public void setSpecialPawn(Ficha specialPawn) {
        this.specialPawn = specialPawn;
    }

    public boolean isWhite() {
        return white;
    }

    public void setWhite(boolean white) {
        this.white = white;
    }

    public boolean isKingSideCastle() {
        return kingSideCastle;
    }

    public void setKingSideCastle(boolean kingSideCastle) {
        this.kingSideCastle = kingSideCastle;
    }

    public boolean isQueenSideCastle() {
        return queenSideCastle;
    }

    public void setQueenSideCastle(boolean queenSideCastle) {
        this.queenSideCastle = queenSideCastle;
    }

    public int getTypeOfConstructor() {
        return typeOfConstructor;
    }

    public void setTypeOfConstructor(int typeOfConstructor) {
        this.typeOfConstructor = typeOfConstructor;
    }

    public boolean notReverse() {
        return !reverse;
    }

    public void setReverse(boolean reverse) {
        this.reverse = reverse;
    }

    public String getStringMove() {
        return stringMove;
    }

    public void setStringMove(String stringMove) {
        this.stringMove = stringMove;
    }

    /**
     * set new piece on given square
     */
    private void setNewPosition(Recuadros square, Ficha piece){
        int[] position = Metodo.getPosition(square);
        Tablero.finalPositions[position[0]][position[1]] = Metodo.getNotationPiece(piece);
        Recuadros.piece.put(square, piece);
    }

    /**
     * set new piece on given position
     */
    private void setNewPosition(int[] position, Ficha piece){
        Tablero.finalPositions[position[0]][position[1]] = Metodo.getNotationPiece(piece);
        Recuadros.piece.put(Metodo.getSquare(position), piece);
    }

    /**
     * return name of given piece
     */
    private String stringPiece(Ficha piece){
        switch (piece) {
            case WHITE_ROOK -> {
                return "White Rook";
            }
            case WHITE_KING -> {
                return "White King";
            }
            case WHITE_PAWN -> {
                return "White Pawn";
            }
            case WHITE_QUEEN -> {
                return "White Queen";
            }
            case WHITE_BISHOP -> {
                return "White Bishop";
            }
            case WHITE_KNIGHT -> {
                return "White Knight";
            }
            case BLACK_KING -> {
                return "Black King";
            }
            case BLACK_PAWN -> {
                return "Black Pawn";
            }
            case BLACK_ROOK -> {
                return "Black Rook";
            }
            case BLACK_QUEEN -> {
                return "Black Queen";
            }
            case BLACK_BISHOP -> {
                return "Black Bishop";
            }
            default -> {
                return "Black Knight";
            }
        }
    }

    @Override
    public String toString() {
        return getStringMove();
    }

    /**
     * toString version 2: it only care about move itself and it exclude capturing act. Bg4 and Bxg4 are same here.
     */
    public String toStringV2(){
        if(getTypeOfConstructor() == 1)
            return "["+ stringPiece(getMovingPiece())+" from "+getFrom()+" to "+getTo()+"]";
        else if(getTypeOfConstructor() == 2) {
            if(getSpecialPawn() == Ficha.NONE) {
                if ((Metodo.getPosition(getTo())[0] != 0 && Metodo.getPosition(getTo())[0] != 7)
                        || (getCaptured() != Ficha.WHITE_PAWN && getCaptured() != Ficha.BLACK_PAWN))
                    return "[" + stringPiece(getMovingPiece()) + " from " + getFrom() + " to " + getTo() + "]";
                else {
                    return "[" + stringPiece(getCaptured()) + " from " + getFrom() + " to " + getTo() + " promote to " + stringPiece(getMovingPiece()) + "]";
                }
            } else {
                return "[" + stringPiece(getSpecialPawn()) + " from " + getFrom() + " to " + getTo() + " promote to " + stringPiece(getMovingPiece()) + "]";
            }
        }
        else {
            if (isWhite()) {
                if (isKingSideCastle())
                    return "[White King Side Castle]";
                else
                    return "[White Queen Side Castle]";
            } else {
                if (isKingSideCastle())
                    return "[Black King Side Castle]";
                else
                    return "[Black Queen Side Castle]";
            }
        }
    }

    @Override
    public boolean equals(Object o){
        if(o.getClass() == this.getClass()) {
            Movimientos m = (Movimientos) o;
            if (this.getTypeOfConstructor() == m.getTypeOfConstructor()) {
                if (this.getTypeOfConstructor() == 1 && this.getFrom() == m.getFrom() && this.getTo() == m.getTo()
                        && this.getMovingPiece() == m.getMovingPiece())
                    return true;
                else if (this.getTypeOfConstructor() == 2 && this.getFrom() == m.getFrom() && this.getTo() == m.getTo()
                        && this.getMovingPiece() == m.getMovingPiece()) {
                    if(this.getSpecialPawn() == m.getSpecialPawn() && this.getSpecialPawn() == Ficha.NONE) {
                        if ((Metodo.getPosition(getTo())[0] != 0 && Metodo.getPosition(getTo())[0] != 7)
                                || (getCaptured() != Ficha.WHITE_PAWN && getCaptured() != Ficha.BLACK_PAWN)) {
                            return true;
                        } else {
                            return this.getCaptured() == m.getCaptured();
                        }
                    } else return this.getSpecialPawn() == m.getSpecialPawn() && this.getCaptured() == m.getCaptured();
                }
                else return this.getTypeOfConstructor() == 3 && this.isWhite() == m.isWhite()
                            && this.isKingSideCastle() == m.isKingSideCastle()
                            && this.isQueenSideCastle() == m.isQueenSideCastle();
            } else
                return false;
        } else
            return false;
    }
}

