package Controlador;

import Modelo.Movimientos;
import Modelo.Ficha;
import Modelo.Recuadros;

import java.util.ArrayList;
import java.util.Arrays;

public class Conversor extends Metodo {
    /**
     * it convert a move from model.PGN notation to a model.Move object.
     * first it detect moves by their length and then by special notation that would separate their type of move
     * from others.
     * then it detect initial and final position of move and add the move to an Arraylist of model.Move objects.
     */
    public static ArrayList<Movimientos> convertMoves(String[] movesArray){
        ArrayList<Movimientos> movimientos = new ArrayList<>();
        resetSquares();
        for (int i = 0; i < movesArray.length; i++) {
            String s = movesArray[i];
            switch (s.length()) {
                case 2 -> {
                    int[] position = getPosition(s);
                    int[] initial = detectPawn(i, position, '0');
                    movimientos.add(new Movimientos(getSquare(initial), getSquare(position), getPiece(initial), s));
                }
                case 3 -> {
                    if (s.equals("O-O")) {
                        movimientos.add(new Movimientos(i % 2 == 0, true, false, false, s));
                    } else {
                        String piece = String.valueOf(s.charAt(0));
                        int[] position = getPosition(s.charAt(1) + String.valueOf(s.charAt(2)));
                        int[] initial = detectPiece(i, piece, position, false);
                        movimientos.add(new Movimientos(getSquare(initial), getSquare(position), getPiece(initial), s));
                    }
                }
                case 4 -> {
                    if (s.contains("=")) {
                        int[] position = getPosition(s.charAt(0) + String.valueOf(s.charAt(1)));
                        int[] initial = detectPawn(i, position, '0');
                        movimientos.add(new Movimientos(getSquare(initial), getSquare(position), getPiece(i, s.charAt(3)), getPiece(initial), Ficha.NONE, false, s));
                    } else if (s.contains("x")) {
                        int[] position = getPosition(s.charAt(2) + String.valueOf(s.charAt(3)));
                        int[] initial;
                        if (Character.isUpperCase(s.charAt(0))) {
                            String piece = String.valueOf(s.charAt(0));
                            initial = detectPiece(i, piece, position, true);
                        } else {
                            initial = detectPawn(i, position, Character.toUpperCase(s.charAt(0)));
                        }
                        movimientos.add(new Movimientos(getSquare(initial), getSquare(position), getPiece(initial), getPiece(position), Ficha.NONE, false, s));
                    } else if (Character.isLowerCase(s.charAt(1))) {
                        String piece = String.valueOf(s.charAt(0));
                        String y = String.valueOf(s.charAt(1));
                        int[] position = getPosition(s.charAt(2) + String.valueOf(s.charAt(3)));
                        int[] initial = detectPieceGivenInformation(i, piece, null, y, position);
                        movimientos.add(new Movimientos(getSquare(initial), getSquare(position), getPiece(initial), s));
                    } else {
                        String piece = String.valueOf(s.charAt(0));
                        String x = String.valueOf(s.charAt(1));
                        int[] position = getPosition(s.charAt(2) + String.valueOf(s.charAt(3)));
                        int[] initial = detectPieceGivenInformation(i, piece, x, null, position);
                        movimientos.add(new Movimientos(getSquare(initial), getSquare(position), getPiece(initial), s));
                    }
                }
                case 5 -> {
                    if (s.equals("O-O-O")) {
                        movimientos.add(new Movimientos(i % 2 == 0, false, true, false, s));
                    } else if (s.charAt(0) == 'Q' && Character.isLowerCase(s.charAt(1)) && Character.isLowerCase(s.charAt(3))
                            && Character.isDigit(s.charAt(2)) && Character.isDigit(s.charAt(4))){
                        int[] initial = getPosition(s.charAt(1) + String.valueOf(s.charAt(2)));
                        int[] position = getPosition(s.charAt(3) + String.valueOf(s.charAt(4)));
                        movimientos.add(new Movimientos(getSquare(initial), getSquare(position), getPiece(initial), s));
                    }
                    else if (Character.isLowerCase(s.charAt(1))) {
                        String piece = String.valueOf(s.charAt(0));
                        String y = String.valueOf(s.charAt(1));
                        int[] position = getPosition(s.charAt(3) + String.valueOf(s.charAt(4)));
                        int[] initial = detectPieceGivenInformation(i, piece, null, y, position);
                        movimientos.add(new Movimientos(getSquare(initial), getSquare(position), getPiece(initial), getPiece(position), Ficha.NONE, false, s));
                    }
                    else {
                        String piece = String.valueOf(s.charAt(0));
                        String x = String.valueOf(s.charAt(1));
                        int[] position = getPosition(s.charAt(3) + String.valueOf(s.charAt(4)));
                        int[] initial = detectPieceGivenInformation(i, piece, x, null, position);
                        movimientos.add(new Movimientos(getSquare(initial), getSquare(position), getPiece(initial), getPiece(position), Ficha.NONE, false, s));
                    }
                }
                case 6 -> {
                    if(s.contains("=")) {
                        int[] position = getPosition(s.charAt(2) + String.valueOf(s.charAt(3)));
                        int[] initial = detectPawn(i, position, Character.toUpperCase(s.charAt(0)));
                        movimientos.add(new Movimientos(getSquare(initial), getSquare(position), getPiece(i, s.charAt(5)), getPiece(position), getPiece(initial), false, s));
                    }
                    else if(s.contains("x")){
                        int[] initial = getPosition(s.charAt(1) + String.valueOf(s.charAt(2)));
                        int[] position = getPosition(s.charAt(4) + String.valueOf(s.charAt(5)));
                        movimientos.add(new Movimientos(getSquare(initial), getSquare(position), getPiece(initial), getPiece(position), Ficha.NONE, false, s));
                    }
                }
            }
        }
        return movimientos;
    }

    /**
     * it detect initial position of a Pawn movement.
     * @param i
     * index of move to determine white or black.
     * @param position
     * final position of move
     * @param s1
     * it's the first letter of move string when pawn's movement does include capturing.
     * "exd5" => s1 = 'e'
     * '0' => declare that movement does not include capturing. like "e5" => s1 = '0'
     */
    public static int[] detectPawn(int i, int[] position, char s1){
        if(i % 2 == 0) {
            if(s1 == '0') {
                if (getPiece(new int[]{position[0] - 1, position[1]}) == Ficha.WHITE_PAWN)
                    return new int[]{position[0] - 1, position[1]};
                else
                    return new int[]{position[0] - 2, position[1]};
            } else
                return getPosition(s1+String.valueOf(position[0]));
        } else {
            if(s1 == '0') {
                if (getPiece(new int[]{position[0] + 1, position[1]}) == Ficha.BLACK_PAWN)
                    return new int[]{position[0] + 1, position[1]};
                else
                    return new int[]{position[0] + 2, position[1]};
            } else
                return getPosition(s1+String.valueOf(position[0]+2));
        }
    }

    /**
     * it detect initial position of a piece movement. there is a different method for each type of piece.
     * for Rooks it looks for a suitable rook in squares that are vertical or horizontal to final position.
     * for Bishops it looks for a suitable bishop in squares that are diagonal to final position.
     * for Knights it looks for a suitable knight in 8 squares that a knight could be before moving to final position.
     * for Queen it looks for a suitable queen in squares that are vertical or horizontal or diagonal to final position.
     * for King it looks for a suitable king in 8 squares that a king could be before moving to final position.
     * @param i
     * index of move
     * @param piece
     * moving piece
     * @param position
     * final position of move
     * @param capture
     * indicate whether movement does include capture or not.
     */
    public static int[] detectPiece(int i, String piece, int[] position, boolean capture) {
        Ficha targetPiece = (i % 2 == 0) ? getWhitePiece(piece) : getBlackPiece(piece);

        switch (piece.toUpperCase()) {
            case "R":
                return detectRookPosition(i, position, targetPiece, capture);
            case "B":
                return detectBishopPosition(i, position, targetPiece, capture);
            case "N":
                return detectKnightPosition(i, position, targetPiece);
            case "Q":
                int[] rookMove = detectRookPosition(i, position, targetPiece, capture);
                return rookMove.length > 0 ? rookMove : detectBishopPosition(i, position, targetPiece, capture);
            case "K":
                return detectKingPosition(i, position, targetPiece);
        }
        return new int[]{};
    }

    private static Ficha getWhitePiece(String piece) {
        return switch (piece.toUpperCase()) {
            case "R" -> Ficha.WHITE_ROOK;
            case "B" -> Ficha.WHITE_BISHOP;
            case "N" -> Ficha.WHITE_KNIGHT;
            case "Q" -> Ficha.WHITE_QUEEN;
            case "K" -> Ficha.WHITE_KING;
            default -> null;
        };
    }

    private static Ficha getBlackPiece(String piece) {
        return switch (piece.toUpperCase()) {
            case "R" -> Ficha.BLACK_ROOK;
            case "B" -> Ficha.BLACK_BISHOP;
            case "N" -> Ficha.BLACK_KNIGHT;
            case "Q" -> Ficha.BLACK_QUEEN;
            case "K" -> Ficha.BLACK_KING;
            default -> null;
        };
    }

    private static int[] detectRookPosition(int i, int[] position, Ficha targetPiece, boolean capture) {
        for (int j = 0; j < 8; j++) {
            int[][] initialPositions = {{j, position[1]}, {position[0], j}};
            for (int[] initial : initialPositions) {
                if (getPiece(initial) == targetPiece && isAllowedMove(initial, position, capture, "horizontalOrVertical")
                        && isAllowedCheck(i, getSquare(initial), getSquare(position), targetPiece)) {
                    return initial;
                }
            }
        }
        return new int[]{};
    }

    private static int[] detectBishopPosition(int i, int[] position, Ficha targetPiece, boolean capture) {
        for (int j = -7; j < 8; j++) {
            int[][] initialPositions = {
                    {position[0] + j, position[1] + j},
                    {position[0] + j, position[1] - j}
            };
            for (int[] initial : initialPositions) {
                if (isWithinBounds(initial) && getPiece(initial) == targetPiece
                        && isAllowedMove(initial, position, capture, "diagonally")
                        && isAllowedCheck(i, getSquare(initial), getSquare(position), targetPiece)) {
                    return initial;
                }
            }
        }
        return new int[]{};
    }

    private static int[] detectKnightPosition(int i, int[] position, Ficha targetPiece) {
        int[][] moves = {
                {-1, -2}, {-1, 2}, {-2, -1}, {-2, 1},
                {1, -2}, {1, 2}, {2, -1}, {2, 1}
        };
        for (int[] move : moves) {
            int[] initial = {position[0] + move[0], position[1] + move[1]};
            if (isWithinBounds(initial) && getPiece(initial) == targetPiece && isAllowedCheck(i, getSquare(initial), getSquare(position), targetPiece)) {
                return initial;
            }
        }
        return new int[]{};
    }

    private static int[] detectKingPosition(int i, int[] position, Ficha targetPiece) {
        for (int j = -1; j <= 1; j++) {
            for (int k = -1; k <= 1; k++) {
                int[] initial = {position[0] + j, position[1] + k};
                if (isWithinBounds(initial) && getPiece(initial) == targetPiece) {
                    return initial;
                }
            }
        }
        return new int[]{};
    }

    private static boolean isWithinBounds(int[] position) {
        return position[0] >= 0 && position[0] <= 7 && position[1] >= 0 && position[1] <= 7;
    }


    /**
     * it detect initial position of a piece movement when some extra information provided in string move.
     * @param i
     * index of move
     * @param piece
     * moving piece
     * @param x
     * information about x axis.
     * @param y
     * information about y axis.
     * @param position
     * final position of move
     */
    public static int[] detectPieceGivenInformation(int i, String piece, String x, String y, int[] position){
        if(x != null) {
            int x1 = Integer.parseInt(x)-1;
            switch (piece.toUpperCase()) {
                case "R":
                    return new int[]{x1, position[1]};
                case "N":
                    if(position[1]-1 >= 0) {
                        int[] initial = new int[]{x1, position[1] - 1};
                        if(i % 2 == 0) {
                            if (getPiece(initial) == Ficha.WHITE_KNIGHT)
                                return initial;
                        } else {
                            if (getPiece(initial) == Ficha.BLACK_KNIGHT)
                                return initial;
                        }
                    }
                    if(position[1]-2 >= 0) {
                        int[] initial = new int[]{x1, position[1] - 2};
                        if(i % 2 == 0) {
                            if (getPiece(initial) == Ficha.WHITE_KNIGHT)
                                return initial;
                        } else {
                            if (getPiece(initial) == Ficha.BLACK_KNIGHT)
                                return initial;
                        }
                    }
                    if(position[1]+1 <= 7) {
                        int[] initial = new int[]{x1, position[1] + 1};
                        if(i % 2 == 0) {
                            if (getPiece(initial) == Ficha.WHITE_KNIGHT)
                                return initial;
                        } else {
                            if (getPiece(initial) == Ficha.BLACK_KNIGHT)
                                return initial;
                        }
                    }
                    if(position[1]+2 <= 7) {
                        int[] initial = new int[]{x1, position[1] + 2};
                        if(i % 2 == 0) {
                            if (getPiece(initial) == Ficha.WHITE_KNIGHT)
                                return initial;
                        } else {
                            if (getPiece(initial) == Ficha.BLACK_KNIGHT)
                                return initial;
                        }
                    }
                    break;
                case "B":
                    for(int j = 0; j <= 7; j++){
                        int[] initial = new int[]{x1, j};
                        if(i % 2 == 0) {
                            if (getPiece(initial) == Ficha.WHITE_BISHOP)
                                return initial;
                        } else {
                            if (getPiece(initial) == Ficha.BLACK_BISHOP)
                                return initial;
                        }
                    }
                    break;
                case "Q":
                    for(int j = 0; j <= 7; j++){
                        int[] initial = new int[]{x1, j};
                        if(i % 2 == 0) {
                            if (getPiece(initial) == Ficha.WHITE_QUEEN)
                                return initial;
                        } else {
                            if (getPiece(initial) == Ficha.BLACK_QUEEN)
                                return initial;
                        }
                    }
                    break;
            }
        } else {
            int y1;
            switch (y.toUpperCase()){
                case ("A") -> y1 = 0;
                case ("B") -> y1 = 1;
                case ("C") -> y1 = 2;
                case ("D") -> y1 = 3;
                case ("E") -> y1 = 4;
                case ("F") -> y1 = 5;
                case ("G") -> y1 = 6;
                default -> y1 = 7;
            }
            switch (piece.toUpperCase()) {
                case "R":
                    if(y1 != position[1])
                        return new int[]{position[0], y1};
                    else{
                        for(int k = 0; k <= 7; k++){
                            int[] initial = new int[]{k, y1};
                            if(i % 2 == 0) {
                                if(getPiece(initial) == Ficha.WHITE_ROOK)
                                    return new int[]{k, y1};
                            } else {
                                if(getPiece(initial) == Ficha.BLACK_ROOK)
                                    return new int[]{k, y1};
                            }
                        }
                    }
                    break;
                case "N":
                    if(position[0]-1 >= 0) {
                        int[] initial = new int[]{position[0] - 1, y1};
                        if(i % 2 == 0) {
                            if (getPiece(initial) == Ficha.WHITE_KNIGHT)
                                return initial;
                        } else {
                            if (getPiece(initial) == Ficha.BLACK_KNIGHT)
                                return initial;
                        }
                    }
                    if(position[0]-2 >= 0) {
                        int[] initial = new int[]{position[0] - 2, y1};
                        if(i % 2 == 0) {
                            if (getPiece(initial) == Ficha.WHITE_KNIGHT)
                                return initial;
                        } else {
                            if (getPiece(initial) == Ficha.BLACK_KNIGHT)
                                return initial;
                        }
                    }
                    if(position[0]+1 <= 7) {
                        int[] initial = new int[]{position[0] + 1, y1};
                        if(i % 2 == 0) {
                            if (getPiece(initial) == Ficha.WHITE_KNIGHT)
                                return initial;
                        } else {
                            if (getPiece(initial) == Ficha.BLACK_KNIGHT)
                                return initial;
                        }
                    }
                    if(position[0]+2 <= 7) {
                        int[] initial = new int[]{position[0] + 2, y1};
                        if(i % 2 == 0) {
                            if (getPiece(initial) == Ficha.WHITE_KNIGHT)
                                return initial;
                        } else {
                            if (getPiece(initial) == Ficha.BLACK_KNIGHT)
                                return initial;
                        }
                    }
                    break;
                case "B":
                    for(int j = 0; j <= 7; j++){
                        int[] initial = new int[]{j, y1};
                        if(i % 2 == 0) {
                            if (getPiece(initial) == Ficha.WHITE_BISHOP)
                                return initial;
                        } else {
                            if (getPiece(initial) == Ficha.BLACK_BISHOP)
                                return initial;
                        }
                    }
                    break;
                case "Q":
                    for(int j = 0; j <= 7; j++){
                        int[] initial = new int[]{j, y1};
                        if(i % 2 == 0) {
                            if (getPiece(initial) == Ficha.WHITE_QUEEN)
                                return initial;
                        } else {
                            if (getPiece(initial) == Ficha.BLACK_QUEEN)
                                return initial;
                        }
                    }
                    break;
            }
        }
        return new int[]{};
    }

    /**
     * if a piece stops a check, then we are not allow to moving it.
     * it detect king's position and check if the move happens is there any clear path to king vertically, horizontally
     * and diagonally or not. if there was then it would not allow it and return false.
     * @param i
     * index of move
     * @param from
     * initial square
     * @param to
     * final square
     * @param piece
     * moving piece
     */
    public static boolean isAllowedCheck(int i, Recuadros from, Recuadros to, Ficha piece) {
        // Guarda el estado actual
        Ficha originalToPiece = Recuadros.piece.get(to);
        Recuadros.piece.put(from, Ficha.NONE);
        Recuadros.piece.put(to, piece);

        int[] kingPosition = findKingPosition(i % 2 == 0 ? Ficha.WHITE_KING : Ficha.BLACK_KING);

        for (Recuadros s : Recuadros.values()) {
            Ficha currentPiece = Recuadros.piece.get(s);
            if (currentPiece != Ficha.NONE && !isPathClear(kingPosition, s, currentPiece)) {
                resetBoardState(from, to, piece, originalToPiece);
                return false;
            }
        }

        resetBoardState(from, to, piece, originalToPiece);
        return true;
    }

    private static void resetBoardState(Recuadros from, Recuadros to, Ficha originalFrom, Ficha originalTo) {
        Recuadros.piece.put(from, originalFrom);
        Recuadros.piece.put(to, originalTo);
    }

    private static int[] findKingPosition(Ficha kingPiece) {
        for (Recuadros s : Recuadros.values()) {
            if (Recuadros.piece.get(s) == kingPiece) {
                return Recuadros.position.get(s);
            }
        }
        return null; // Nunca debería ocurrir en un juego válido
    }

    private static boolean isPathClear(int[] kingPosition, Recuadros from, Ficha piece) {
        int[] fromPosition = Recuadros.position.get(from);
        switch (piece) {
            case BLACK_ROOK:
            case WHITE_ROOK:
                return isStraightPathClear(kingPosition, fromPosition);
            case BLACK_BISHOP:
            case WHITE_BISHOP:
                return isDiagonalPathClear(kingPosition, fromPosition);
            case BLACK_QUEEN:
            case WHITE_QUEEN:
                return isStraightPathClear(kingPosition, fromPosition) || isDiagonalPathClear(kingPosition, fromPosition);
            default:
                return true;
        }
    }

    private static boolean isStraightPathClear(int[] start, int[] end) {
        // Implementa la verificación de obstrucción en un camino recto (horizontal o vertical)
        return true;
    }

    private static boolean isDiagonalPathClear(int[] start, int[] end) {
        // Implementa la verificación de obstrucción en un camino diagonal
        return true;
    }


    /**
     * if a move cannot be done (because another piece is between initial and final position)
     * it would not allow it.
     * @param initial
     * initial position
     * @param position
     * final position
     * @param capture
     * indicate whether movement does include capture or not.
     * @param type
     * type of movement: "horizontally" - "vertically" - "diagonally"
     */
    public static boolean isAllowedMove(int[] initial, int[] position, boolean capture, String type){
        boolean allowed = true;
        if(type.equals("vertically")){
            for (int k = Math.min(initial[0], position[0]); k <= Math.max(initial[0], position[0]); k++) {
                if (k != initial[0]) {
                    if (getPiece(new int[]{k, position[1]}) != Ficha.NONE) {
                        if(capture){
                            if(!Arrays.equals(new int[]{k, position[1]}, position)) {
                                allowed = false;
                                break;
                            }
                        } else {
                            allowed = false;
                            break;
                        }
                    }
                }
            }
        }
        else if(type.equals("horizontally")){
            for (int k = Math.min(initial[1], position[1]); k <= Math.max(initial[1], position[1]); k++) {
                if (k != initial[1]) {
                    if (getPiece(new int[]{position[0], k}) != Ficha.NONE) {
                        if(capture){
                            if(!Arrays.equals(new int[]{position[0], k}, position)) {
                                allowed = false;
                                break;
                            }
                        } else {
                            allowed = false;
                            break;
                        }
                    }
                }
            }
        }
        else {
            if((initial[0] + initial[1]) % 2 == (position[0] + position[1]) % 2
                    && Math.abs(position[0]-initial[0]) == Math.abs(position[1]-initial[1])){
                if(position[0] > initial[0] && position[1] > initial[1]){
                    for (int j = 1; j < Math.max(position[0]-initial[0], position[1]-initial[1]); j++) {
                        int[] pos = new int[]{initial[0] + j, initial[1] + j};
                        if(initial[0] + j >=0 && initial[0] + j <=7 &&
                                initial[1] + j >=0 && initial[1] + j <= 7) {
                            if (getPiece(pos) != Ficha.NONE) {
                                if(capture){
                                    if(!Arrays.equals(pos, position)) {
                                        allowed = false;
                                        break;
                                    }
                                } else {
                                    allowed = false;
                                    break;
                                }
                            }
                        }
                    }
                }
                else if(position[0] > initial[0] && position[1] < initial[1]){
                    for (int j = 1; j < Math.max(position[0]-initial[0], initial[1]-position[1]); j++) {
                        int[] pos = new int[]{initial[0] + j, initial[1] - j};
                        if(initial[0] + j >=0 && initial[0] + j <=7 &&
                                initial[1] - j >=0 && initial[1] - j <= 7) {
                            if (getPiece(pos) != Ficha.NONE) {
                                if(capture){
                                    if(!Arrays.equals(pos, position)) {
                                        allowed = false;
                                        break;
                                    }
                                } else {
                                    allowed = false;
                                    break;
                                }
                            }
                        }
                    }
                }
                else if(position[0] < initial[0] && position[1] > initial[1]){
                    for (int j = 1; j < Math.max(initial[0]-position[0], position[1]-initial[1]); j++) {
                        int[] pos = new int[]{initial[0] - j, initial[1] + j};
                        if(initial[0] - j >=0 && initial[0] - j <=7 &&
                                initial[1] + j >=0 && initial[1] + j <= 7) {
                            if (getPiece(pos) != Ficha.NONE) {
                                if(capture){
                                    if(!Arrays.equals(pos, position)) {
                                        allowed = false;
                                        break;
                                    }
                                } else {
                                    allowed = false;
                                    break;
                                }
                            }
                        }
                    }
                }
                else if(position[0] < initial[0] && position[1] < initial[1]){
                    for (int j = 1; j < Math.max(initial[0]-position[0], initial[1]-position[1]); j++) {
                        int[] pos = new int[]{initial[0] - j, initial[1] - j};
                        if(initial[0] - j >=0 && initial[0] - j <=7 &&
                                initial[1] - j >=0 && initial[1] - j <= 7) {
                            if (getPiece(pos) != Ficha.NONE) {
                                if(capture){
                                    if(!Arrays.equals(pos, position)) {
                                        allowed = false;
                                        break;
                                    }
                                } else {
                                    allowed = false;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
        return allowed;
    }

}

