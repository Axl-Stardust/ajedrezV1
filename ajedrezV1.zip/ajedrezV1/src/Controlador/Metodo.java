package Controlador;

import Modelo.Ficha;
import Modelo.Recuadros;

public class Metodo {
    /**
     * return square from given position.
     */
    public static Recuadros getSquare(int[] position){
        String name = null;

        switch (position[1]){
            case 0 -> name = "A";
            case 1 -> name = "B";
            case 2 -> name = "C";
            case 3 -> name = "D";
            case 4 -> name = "E";
            case 5 -> name = "F";
            case 6 -> name = "G";
            case 7 -> name = "H";
        }
        name += position[0]+1;
        return Recuadros.valueOf(name);
    }

    /**
     * return position from given square.
     */
    public static int[] getPosition(Recuadros square){
        return Recuadros.position.get(square);
    }

    /**
     * return position from given string of square.
     */
    public static int[] getPosition(String s){
        return Recuadros.position.get(Recuadros.valueOf(s.toUpperCase()));
    }

    /**
     * return piece from given position.
     */
    public static Ficha getPiece(int[] position){
        return Recuadros.piece.get(getSquare(position));
    }

    /**
     * return piece from given index of move and character of first letter of piece.
     * it use index of move to determine white or black.
     */
    public static Ficha getPiece(int i, char c){
        String s = String.valueOf(c);
        if(i % 2 == 0)
            s = s.toUpperCase();
        else
            s = s.toLowerCase();
        switch (s){
            case "P" -> {
                return Ficha.WHITE_PAWN;
            }
            case "R" -> {
                return Ficha.WHITE_ROOK;
            }
            case "N" -> {
                return Ficha.WHITE_KNIGHT;
            }
            case "B" -> {
                return Ficha.WHITE_BISHOP;
            }
            case "Q" -> {
                return Ficha.WHITE_QUEEN;
            }
            case "K" -> {
                return Ficha.WHITE_KING;
            }
            case "p" -> {
                return Ficha.BLACK_PAWN;
            }
            case "r" -> {
                return Ficha.BLACK_ROOK;
            }
            case "n" -> {
                return Ficha.BLACK_KNIGHT;
            }
            case "b" -> {
                return Ficha.BLACK_BISHOP;
            }
            case "q" -> {
                return Ficha.BLACK_QUEEN;
            }
            case "k" -> {
                return Ficha.BLACK_KING;
            }
        }
        return null;
    }

    /**
     * return notation of piece from given piece.
     */
    public static char getNotationPiece(Ficha piece){
        return Ficha.notation.get(piece);
    }

    /**
     * return notation of piece from given position.
     */
    public static char getNotationPiece(int[] position){
        return Ficha.notation.get(Recuadros.piece.get(getSquare(position)));
    }

    /**
     * it reset relation between squares and pieces to initial position of chess.
     */
    public static void resetSquares(){
        Recuadros[] square = Recuadros.values();
        for (Recuadros s : square) {
            String[] arr = s.toString().split("");
            switch (arr[1]) {
                case "1":
                    switch (arr[0]) {
                        case "A", "H" -> Recuadros.piece.put(s, Ficha.WHITE_ROOK);
                        case "B", "G" -> Recuadros.piece.put(s, Ficha.WHITE_KNIGHT);
                        case "C", "F" -> Recuadros.piece.put(s, Ficha.WHITE_BISHOP);
                        case "D" -> Recuadros.piece.put(s, Ficha.WHITE_QUEEN);
                        case "E" -> Recuadros.piece.put(s, Ficha.WHITE_KING);
                    }
                    break;
                case "8":
                    switch (arr[0]) {
                        case "A", "H" -> Recuadros.piece.put(s, Ficha.BLACK_ROOK);
                        case "B", "G" -> Recuadros.piece.put(s, Ficha.BLACK_KNIGHT);
                        case "C", "F" -> Recuadros.piece.put(s, Ficha.BLACK_BISHOP);
                        case "D" -> Recuadros.piece.put(s, Ficha.BLACK_QUEEN);
                        case "E" -> Recuadros.piece.put(s, Ficha.BLACK_KING);
                    }
                    break;
                case "2":
                    Recuadros.piece.put(s, Ficha.WHITE_PAWN);
                    break;
                case "7":
                    Recuadros.piece.put(s, Ficha.BLACK_PAWN);
                    break;
                default:
                    Recuadros.piece.put(s, Ficha.NONE);
                    break;
            }
        }
    }
}
