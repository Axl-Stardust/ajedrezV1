README: FUNCIONAMIENTO DEL ARCHIVO

El programa es una aplicación diseñada para analizar y visualizar partidas de ajedrez almacenadas en archivos PGN (Portable Game Notation). PGN es un formato estándar ampliamente utilizado para compartir partidas de ajedrez, que incluye información como los jugadores, la fecha, el resultado y la secuencia de movimientos. Este programa permite a los usuarios cargar y explorar partidas de manera interactiva con diversas funcionalidades accesibles a través de botones en la interfaz gráfica. A continuación, se describen las opciones disponibles:

1. Abrir archivo PGN
Este botón permite al usuario cargar un archivo PGN desde el sistema de archivos. Una vez cargado, el programa procesa el archivo para extraer información relevante como etiquetas (jugadores, evento, fecha, etc.) y la lista de movimientos de la partida.

2. Iniciar partida
Este botón inicializa la partida en el programa. Resetea cualquier progreso actual, coloca las piezas en la posición inicial y prepara la interfaz para navegar a través de los movimientos.Se activa después de cargar un archivo PGN.

3. Jugada anterior y Siguiente jugada
Estos botones permiten al usuario moverse hacia atrás o adelante en la lista de jugadas completas (que incluyen movimientos de ambos jugadores).

- Jugada anterior: Retrocede una jugada, restaurando la posición del tablero al estado anterior.
- Siguiente jugada: Avanza a la siguiente jugada, actualizando el tablero en consecuencia.

4. Primera jugada y Última jugada
Estos botones facilitan saltar directamente al comienzo o al final de la partida.

- Primera jugada: Restablece el tablero a su posición inicial.
- Última jugada: Muestra la posición final de la partida, útil para analizar el desenlace.

5. Buscar jugada por número
Permite a los usuarios ingresar el número de una jugada específica y saltar directamente a ella. Esto es útil para analizar un momento concreto de la partida.

6. Movimiento anterior y Siguiente movimiento
Estos botones permiten navegar individualmente por los movimientos de cada jugador (blancas o negras).

- Movimiento anterior: Retrocede un movimiento en la secuencia de la partida, afectando solo al jugador que realizó el último movimiento.
- Siguiente movimiento: Avanza al siguiente movimiento en la secuencia.

7. Resetear partida
Este botón devuelve el programa a su estado inicial, limpiando los datos cargados y restaurando el tablero a su posición original.

8. Final de la partida
Este botón permite al usuario marcar o guardar el estado final de la partida para revisarla más adelante. Es útil para resaltar la conclusión de la partida.

9. Buscar movimiento por color de pieza y número
Esta opción avanzada permite a los usuarios buscar un movimiento específico según el color de la pieza que lo realizó y su número de aparición en la partida (por ejemplo, "el tercer movimiento de las blancas").

Interfaz gráfica
La interfaz combina un panel principal para el tablero de ajedrez y varios paneles adicionales para los controles, las etiquetas PGN y la lista de movimientos. La disposición podría incluir:

- Panel lateral izquierdo: Un tablero de ajedrez interactivo que refleja el estado actual de la partida.
- Panel lateral derecho: Texto que muestra la información PGN y los movimientos.
- Panel inferior: Botones de control para las funcionalidades descritas.
